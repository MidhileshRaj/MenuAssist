from django.urls import path
from . import views

urlpatterns=[

    path('login/',views.login_),
    path('login_post/',views.login_post),

    path('home/',views.home),

    path('user_inform/',views.user_inform),

    path('add_food/',views.add_food),
    path('add_food_post/',views.add_food_post),

    path('edit_food/',views.edit_food),
    path('edit_food_post/',views.edit_food_post),


    path('view_food/',views.view_food),

    path('add_staff/',views.add_staff),
    path('add_staff_post/',views.add_staff_post),

    path('edit_staff/',views.edit_staff),
    path('edit_staff_post/',views.edit_staff_post),

    path('view_staff/',views.view_staff),

    path('add_tableno/',views.add_tableno),
    path('add_tableno_post/',views.add_tableno_post),

    path('view_tableno/',views.view_tableno),


#   kitchen
    path('kitchen_feedback/',views.kitchen_feedback),

    path('kitchen_order_details/',views.kitchen_order_details),

    path('kitchen_orderdet/',views.kitchen_orderdet),


#service station

    path('service_station_bill/',views.service_station_bill),

    path('service_station_helpview/',views.service_station_helpview),

    path('service_station_notification/',views.service_station_notification),


# cashier

path('cashier_billing/',views.cashier_billing),
]