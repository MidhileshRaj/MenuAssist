from django.core.files.storage import FileSystemStorage
from django.shortcuts import render
from django.http import *
from .models import *
import datetime
import time


# Create your views here.
def login_(request):
    return render(request,"loginform.html")

def login_post(request):
    username = request.POST['username']
    password = request.POST['password']
    return HttpResponse('ok')


def home(request):
    return render(request,'ADMIN/home.html')

def user_inform(request):
    return render(request,'ADMIN/user inform.html')


def add_food(request):
    return render(request,'ADMIN/foodmangment.html')

def add_food_post(request):
    Foodname = request.POST['food']
    image = request.FILES['img']

    fs = FileSystemStorage()
    from datetime import datetime
    # dt = time.strftime("%Y%m%d-%H%M%S")
    # s = dt+image.name()
    s = datetime.now().strftime("%Y%m%d%H%M%S")+image.name
    fn = fs.save(s,image)


    category = request.POST['category']
    Discription = request.POST['textarea']
    Price = request.POST['textfield']
    Stock = request.POST['textfield2']

    ob_food=food()
    ob_food.food_item=Foodname
    ob_food.stock=Stock
    ob_food.price=Price
    ob_food.food_image=fs.url(s)
    ob_food_description=Discription
    ob_food.category=category
    ob_food.save()

    return HttpResponse('''<script>alert('Added');window.location='/app/add_food/'</script>''')

def edit_food(request):
    return render(request,'ADMIN/foodmangmntedit.html')

def edit_food_post(request):
    Foodname = request.POST['food']
    image = request.POST['img']
    category = request.POST['category']
    Discription = request.POST['textarea']
    Price = request.POST['textfield']
    Stock = request.POST['textfield2']
    return HttpResponse('ok')

def view_food(request):

    return render(request,'ADMIN/foodview.html')

def add_staff(request):
    return render(request,'ADMIN/staffreg.html')

def add_staff_post(request):
    username=request.POST['name']
    image=request.FILES['fileField']

    fs=FileSystemStorage()
    from datetime import datetime
    s=datetime.now().strftime("%Y%m%d%H%M%S")+image.name
    fn=fs.save(s,image)

    phoneno=request.POST['textfield']
    DOB=request.POST['textfield2']
    email=request.POST['textfield3']
    Place = request.POST['textfield4']
    Post = request.POST['post']
    District = request.POST['district']
    Pincode = request.POST['pin']

    #add login table

    loginobj=login()
    loginobj.username=email
    loginobj.password=phoneno
    loginobj.type='staff'
    loginobj.save()
    lid=loginobj.id
    ob_staff=staff()
    ob_staff.LOGIN_id=lid

    ob_staff.staff_name=username
    ob_staff.staffphone_no=phoneno
    ob_staff.staff_dob=DOB
    ob_staff.staff_email=email
    ob_staff.staff_place=Place
    ob_staff.staff_post=Post
    ob_staff.staff_district=District
    ob_staff.staff_pincode=Pincode
    ob_staff.staff_photo=fs.url(s)
    ob_staff.save()

    return  HttpResponse('''<script>alert('Added');window.location='/app/add_staff/'</script>''')

def edit_staff(request):
    return render(request,'ADMIN/staffregedit.html')

def edit_staff_post(request):
    username = request.POST['name']
    image = request.POST['filefield']
    phoneno = request.POST['textfield']
    DOB = request.POST['textfield2']
    email = request.POST['textfield3']
    adress = request.POST['textarea']
    return HttpResponse('ok')

def view_staff(request):
    return render(request,'ADMIN/staffview.html')

def add_tableno(request):
    return render(request,'ADMIN/tableno.html')

def add_tableno_post(request):
    Tableno=request.POST['textfield']
    no_of_seat = request.POST['seat']

    ob_table = table()
    ob_table.table_no= Tableno
    ob_table.no_of_seats= no_of_seat
    ob_table.table_status="available"
    ob_table.save()

    return HttpResponse('''<script>alert('Added');window.location='/app/add_tableno/'</script>''')


def view_tableno(request):
    # res = table.objects.all()
    return render(request,'ADMIN/tableview.html')

def view_tableno_post(request):
    tableno=request.POST['button']
    return HttpResponse('ok')


#kitchen

def kitchen_feedback(request):
    return render(request,'KITCHEN/feedback.html')

def kitchen_order_details(request):
    return render(request,'KITCHEN/order details.html')

def kitchen_orderdet(request):
    return render(request,'KITCHEN/orderdet.html')

#service station

def service_station_bill(request):
    return render(request,'SERVICE STATION/bill.html')

def service_station_helpview(request):
    return render(request,'SERVICE STATION/helpview.html')

def service_station_notification(request):
    return render(request,'SERVICE STATION/notification.html')

#cashier

def cashier_billing(request):
    return render(request,'CASHIER/billing.html')


